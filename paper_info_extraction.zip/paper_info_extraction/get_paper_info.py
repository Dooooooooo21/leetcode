'''
爬取论文年份、引用、模型等信息
来源：paperswithcode.com

'''
from math import ceil
from bs4 import BeautifulSoup
import requests
import json
import logging
import re
import pandas as pd
from concurrent.futures import ThreadPoolExecutor, as_completed

logging.basicConfig(format='%(asctime)s - [line:%(lineno)d] - %(levelname)s: %(message)s',
                    level=logging.INFO, filename='./papers.log', filemode='a')

base_url = 'https://paperswithcode.com'

type_urls = {
    'CV': '/methods/area/computer-vision',
    # 'NLP': '/methods/area/natural-language-processing',
    # 'audio': '/methods/area/audio',
    # 'Recommendation System': '/task/recommendation-systems',
    # 'Generative': '/methods/category/generative-models'
}

# 参数 page, method_id
query_paper_url = 'https://paperswithcode.com/api/internal/papers/?ordering=has_repo' \
                  '%2C-best_papergithubrepo__githubrepo__stars&page={}&papermethod__method_id={}&search='

proxies = {"http": "http://dwx1057690:.123qweasd@proxy.huawei.com:8080",
           "https": "http://dwx1057690:.123qweasd@proxy.huawei.com:8080"}

# 最大线程数
thread_max_workers = 100


# 发送请求，获取返回内容
def get_content(url):
    try:
        user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) " \
                     "Chrome/77.0.3865.90 Safari/537.36"
        logging.info('requests url: ' + url)
        response = requests.get(url, headers={'User-Agent': user_agent}, proxies=proxies)
        response.raise_for_status()
        response.encoding = response.apparent_encoding
    except Exception:
        logging.exception(Exception)
    else:
        return response.text


def get_all_papers_info(type, content):
    soup = BeautifulSoup(content, 'lxml')
    if type != 'Recommendation System' and type != 'Generative':
        # 第一层请求信息解析，获取三大分类下子分类信息
        children_types_div = soup.find_all('div', attrs={'class': "row task-group-title"})
        for div in children_types_div:
            if 'One-Stage Object Detection Models' not in str(div):
                continue
            _, link = get_links_from_div(div)
            type_content = get_content(base_url + link)
            type_soup = BeautifulSoup(type_content)
            methods = get_methods(type_soup)
            model_page_url_list = get_model_page_urls_from_method(methods)
            paper_info = get_paper_info(model_page_url_list)
            paper_info = get_paper_model_abstract(paper_info)
            paper_info = get_arxiv_cited(paper_info)
            outoput_papers_info(type, paper_info)
            logging.info(str(div) + 'complete.')
    elif type == 'Recommendation System':
        for i in range(1, 21):
            rs_content = get_content(base_url + '?page=' + str(i))
            if not str(rs_content) or 'href="?page' not in str(rs_content):
                break
            soup = BeautifulSoup(rs_content, 'lxml')
            paper_info = parse_rs_content(soup)
            paper_info = get_paper_model_abstract(paper_info)
            paper_info = get_arxiv_cited(paper_info)
            outoput_papers_info(type, paper_info)
    elif type == 'Generative':
        methods = get_methods(soup)
        model_page_url_list = get_model_page_urls_from_method(methods)
        paper_info = get_paper_info(model_page_url_list)
        paper_info = get_paper_model_abstract(paper_info)
        paper_info = get_arxiv_cited(paper_info)
        outoput_papers_info(type, paper_info)


def get_links_from_div(div):
    link_part = div.find('a')
    method = link_part.text.strip()
    link = link_part['href']

    return method, link


# 解析 recommender sys信息
def parse_rs_content(soup):
    paper_info = {}
    paper_entities = soup.find_all('div', attrs={'class': 'entity'})
    for paper_entity in paper_entities:
        paper_link = (paper_entity.a)['href']
        if '/paper/' not in str(paper_link):
            continue
        paper_url, paper_title, paper_year, arxiv_url, model_code_list, paper_star = request_and_parse_paper_info(
            paper_link)
        paper_info[paper_url] = [paper_title, paper_year]

    return paper_info


# 解析获取分类下所有模型，以及模型下论文数量和method_id
def get_methods(soup):
    methods = {}
    methods_table = soup.find('table', attrs={'id': "methodsTable"})
    trs = methods_table.find_all('tr')
    for tr in trs:
        if tr.a:
            link = tr.a['href']
            method_name = tr.a.text.strip()
            if '-' not in tr.img['src']:
                logging.error('get method_id failed: ' + method_name)
                continue
            method_id = tr.img['src'].split('-')[1]
            papers_count = tr.find_all('td', attrs={'class': 'text-center'})[1].text.strip()
            methods[method_name] = [method_id, link, papers_count]
        else:
            continue

    return methods


# 获取 model_page_url_list
def get_model_page_urls_from_method(methods):
    paper_url_list = []
    for name, infos in methods.items():
        pages = ceil(int(infos[2]) / 10) + 1
        method_id = int(infos[0])
        for i in range(1, pages):
            paper_url = query_paper_url.format(i, method_id)
            paper_url_list.append(paper_url)

    return paper_url_list


# 请求 model_page_url 解析返回json信息, 获取论文名称，链接，发布时间
def get_paper_info(paper_url_list):
    paper_info = {}
    executor = ThreadPoolExecutor(max_workers=thread_max_workers)
    paper_result = [executor.submit(request_and_parse_paper_page_json, paper_url) for paper_url in paper_url_list]
    for future in as_completed(paper_result):
        paper_info.update(future.result())

    executor.shutdown()
    return paper_info


def request_and_parse_paper_page_json(paper_page_url):
    paper_info = {}
    content = get_content(paper_page_url)
    if 'results' not in str(content):
        return paper_info
    response_json = json.loads(content)
    paper_results = response_json['results']
    for result in paper_results:
        paper_name = result['title']
        paper_url = result['url']
        paper_year = result['publication_date']
        paper_info[paper_url] = [paper_name, paper_year[:4]]
        logging.info(paper_url + '---' + paper_name + '---' + paper_year)

    return paper_info


# 论文页面获取论文arxiv地址, 论文code
def get_paper_model_abstract(papers_info):
    executor = ThreadPoolExecutor(max_workers=thread_max_workers)
    paper_result = [executor.submit(request_and_parse_paper_info, paper_url) for paper_url in papers_info.keys()]
    for future in as_completed(paper_result):
        paper_url, paper_title, paper_year, arxiv_url, model_code_list, paper_star = future.result()
        papers_info[paper_url].extend([arxiv_url, model_code_list, paper_star])
        logging.info(paper_url + '---' + arxiv_url + '---' + str(model_code_list))

    executor.shutdown()
    return papers_info


def request_and_parse_paper_info(paper_url):
    content = get_content(base_url + paper_url)
    soup = BeautifulSoup(content, 'lxml')
    paper_title = soup.find('div', attrs={'class': 'paper-title'}).h2.text.strip()
    arxiv_url = soup.find('a', attrs={'class': 'badge badge-light'})['href']
    paper_year = (arxiv_url.split('/')[-1])[:4]
    paper_year = '20' + paper_year[:2]
    paper_star = soup.find('div', attrs={'class': 'paper-impl-cell text-nowrap'})
    if paper_star:
        paper_star = paper_star.text.strip()
    else:
        paper_star = 0
    model_code_a = soup.find_all('a', attrs={'class': 'code-table-link'})
    model_code_list = []
    for a in model_code_a:
        model_code_list.append(re.sub('\s+', ' ', a.text.strip()) + '(' + a['href'] + ')')
        break

    return paper_url, paper_title, paper_year, arxiv_url, model_code_list, paper_star


def get_arxiv_cited(papers_info):
    executor = ThreadPoolExecutor(max_workers=thread_max_workers)
    paper_result = [executor.submit(request_and_parse_paper_cited, [url, values[2]]) for url, values in
                    papers_info.items()]
    for future in as_completed(paper_result):
        paper_url, cited_times = future.result()
        papers_info[paper_url].extend([cited_times])
        logging.info(paper_url + '---' + str(cited_times))

    executor.shutdown()
    return papers_info


# arxiv 请求，解析
def request_and_parse_paper_cited(values):
    url = values[0]
    paper_url = values[1]

    cited_times = 0

    # todo 这里直接返回0，后续添加ip池，解决反爬虫问题
    return url, cited_times

    paper_url = paper_url[:-4].replace('pdf', 'abs')
    arxiv_content = get_content(paper_url)
    # if not str(arxiv_content) or 'abs-button abs-button-small cite-google-scholar' not in str(arxiv_content):
    #     return url, cited_times
    soup = BeautifulSoup(arxiv_content, 'lxml')
    # 查找 arxiv 内容中 google_scholar 元素
    google_scholar_a = soup.find('a', attrs={'class': 'abs-button abs-button-small cite-google-scholar'})
    if not google_scholar_a:
        logging.warning(paper_url + ' has no google scholar link.')
        return url, cited_times

    # 获取元素中 google_scholar 链接
    google_scholar_link = google_scholar_a['href']
    google_scholar_content = get_content(google_scholar_link)
    # 正则匹配 google_scholar 页面内容中引用次数部分
    pattern = re.compile(r'被引用次数：[1-9]\d*')
    cited_times_obj = pattern.search(str(google_scholar_content))
    if cited_times_obj:
        cited_times = cited_times_obj.group().split('：')[1]

    return url, cited_times


def outoput_papers_info(type, info):
    columns = ['title', 'year', 'arxiv_url', 'paper_code', 'paper_star', 'cited_times']
    info_df = pd.DataFrame.from_dict(info, orient='index', columns=columns)
    info_df['type'] = type
    info_df.to_csv('./papers_info.csv', sep=',', mode='a', header=False)
    logging.info('output success.')


if __name__ == '__main__':
    for type, url in type_urls.items():
        target_url = base_url + url
        content = get_content(target_url)
        get_all_papers_info(type, content)
