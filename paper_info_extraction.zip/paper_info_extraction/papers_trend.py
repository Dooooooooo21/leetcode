from wordcloud import WordCloud
import pandas as pd


def get_papers_by_year():
    df = pd.read_csv('papers_info.csv')
    df.columns = ['paperwithcode_url', 'title', 'year', 'arxiv_url', 'paper_code', 'paper_star', 'cited_times', 'type']
    years = sorted(set(df['year'].tolist()))
    for year in years[2:-1]:
        print(year)
        year_paper_titles = set(df.loc[df['year'] == year, 'title'].tolist())
        wc = WordCloud(background_color='white', width=1000, height=800).generate_from_text(str(year_paper_titles))
        print(wc.words_)
        wc.to_file('./{}.png'.format(year))


if __name__ == '__main__':
    get_papers_by_year()
