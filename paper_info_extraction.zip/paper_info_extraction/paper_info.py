class PaperInfo:
    def __init__(self, _type):
        self.type = _type
        self.paper_title = None
        self.model_name = None
        self.code = None
        self.year = None
        self.cited_times = None
        self.paperwithcode_url = None
        self.arxiv_url = None