import logging
import pandas as pd
import time
import difflib
import semanticscholar as sch

logging.basicConfig(format='%(asctime)s - [line:%(lineno)d] - %(levelname)s: %(message)s',
                    level=logging.INFO, filename='./google_scholar.log', filemode='a')

proxies = {"http": "http://dwx1057690:.123qweasd@proxy.huawei.com:8080",
           "https": "http://dwx1057690:.123qweasd@proxy.huawei.com:8080"}


# 已经收集到的论文
def get_collected_papers():
    collect_paper_df = pd.read_csv('../data/extracted_feature_0610.csv')
    collect_paper_titles = collect_paper_df['model_paper']
    collect_paper_set = set(collect_paper_titles.tolist())

    return collect_paper_set


def string_similar(s1, s2):
    return difflib.SequenceMatcher(None, s1, s2).quick_ratio()


# 计算论文标题相似度
def cal_likely_papers_title():
    df = pd.read_csv('./titles.csv')
    titles = df['title'].tolist()
    paper_titles = set(titles)
    print('paperwithcode: ', len(paper_titles), sep='')

    collect_paper = get_collected_papers()
    collect_paper.pop()
    print('collected: ', len(collect_paper), sep='')
    count = 0

    for title in collect_paper:
        if title in paper_titles:
            continue
        else:
            likely_max = 0
            likely_title = ''
            for pwc_title in paper_titles:
                likely = string_similar(title, pwc_title)
                if likely > likely_max:
                    likely_max = likely
                    likely_title = pwc_title
            print('相似度: ', likely_max, sep='')
            print(title + ' ----- ' + likely_title)

    print('交集: ', count, sep='')


def get_semantic_infos(arxiv_id):
    paper = sch.paper('arXiv:{}'.format(arxiv_id), timeout=2)
    if paper:
        return paper['numCitedBy']
    else:
        return 0


def get_cited_info():
    df = pd.read_csv('./after_filter.csv')
    df.drop(columns=['Unnamed: 0', 'Unnamed: 0.1'], inplace=True)
    print(df.columns)
    print(len(df))
    count = 0
    for index, row in df.iterrows():
        if 'arxiv' not in row['arxiv_url']:
            continue
        if not row['is_collected']:
            continue
        count += 1
        arxiv_id = row['arxiv_url'].split('/')[4].split('v')[0]
        cited_times = get_semantic_infos(arxiv_id)
        df.loc[df['arxiv_url'] == row['arxiv_url'], 'cited_times'] = cited_times
        print(row['arxiv_url'], cited_times, sep=' ----- ')
        time.sleep(2)
        if count % 50 == 0:
            df.to_csv('update_cited_times.csv')

        if count % 90 == 0:
            time.sleep(360)
    df.to_csv('update_cited_times.csv')


def update_paper_cited_times():
    df = pd.read_csv('./after_filter.csv')
    df.drop(columns=['Unnamed: 0', 'Unnamed: 0.1'], inplace=True)
    with open('cited_times.txt', mode='r') as f:
        lines = f.readlines()
        for line in lines:
            if ' ----- ' not in line:
                continue
            arxiv = line.split(' ----- ')[0].strip()
            cited_times = line.split(' ----- ')[1].strip()
            df.loc[df['arxiv_url'] == arxiv, 'cited_times'] = cited_times

    df.to_csv('update_cited_times.csv', sep=',')


if __name__ == '__main__':
    get_cited_info()
    # update_paper_cited_times()
