'''
处理论文信息

'''
import collections

import pandas as pd
import matplotlib.pyplot as plt


def compare_papers():
    columns = ['paperwithcode_url', 'title', 'year', 'arxiv_url', 'paper_code', 'paper_star', 'cited_times', 'type']
    spider_paper_df = pd.read_csv('./papers_info.csv')
    spider_paper_df.columns = columns
    print('爬取论文数量: ', len(spider_paper_df), sep='')
    spider_paper_df = spider_paper_df[spider_paper_df['paper_code'] != '[]']
    print('有代码论文数量: ', len(spider_paper_df), sep='')
    spider_paper_titles = spider_paper_df['title']
    spider_paper_set = set(spider_paper_titles.tolist())
    print('去重后论文数量: ', len(spider_paper_set), sep='')

    collect_paper_df = pd.read_csv('../data/extracted_feature_0610.csv')
    collect_paper_titles = collect_paper_df['model_paper']
    print('收集到的论文数量: ', len(collect_paper_titles), sep='')
    collect_paper_set = set(collect_paper_titles.tolist())
    print('收集到的论文去重后数量: ', len(collect_paper_set), sep='')

    both_paper_title = (spider_paper_set & collect_paper_set)
    print('交集论文数量: ', len(both_paper_title), sep='')
    print(both_paper_title)

    print(collect_paper_set - spider_paper_set)

    # filter_df = spider_paper_df[spider_paper_df['title'].isin(spider_paper_set)]
    filter_df = spider_paper_df.drop_duplicates(subset='title', keep='first', inplace=False)
    print(len(filter_df))
    filter_df['paperwithcode_url'] = filter_df['paperwithcode_url'].map(lambda a: 'https://paperswithcode.com' + str(a))
    filter_df['arxiv_url'] = filter_df['arxiv_url'].map(lambda a: (a[:-4]).replace('pdf', 'abs'))
    filter_df['paper_code'] = filter_df['paper_code'].map(lambda a: (a[2:-2]))
    filter_df.loc[:, 'is_collected'] = 'False'
    filter_df.loc[filter_df['title'].isin(both_paper_title), 'is_collected'] = 'True'
    filter_df.to_csv('./is_collected.csv', sep=',')
    print(filter_df.columns)


# 分析论文数据
def ana_papers():
    # 读取原始数据
    paper_df = pd.read_csv('./is_collected.csv')
    # 新增 project_name 列
    paper_df['project_name'] = paper_df['paper_code'].map(get_project_name)
    # 将 star 转 int
    paper_df['paper_star'] = paper_df['paper_star'].map(lambda a: int(a.replace(',', '')))

    # 获取github peoject，去重统计分布
    project_df = pd.DataFrame(paper_df, columns=['type', 'project_name', 'paper_star'])
    project_df.drop_duplicates(subset='project_name', keep='first', inplace=True, ignore_index=True)

    type_list = ['CV', 'NLP', 'Generative', 'Recommendation System', 'audio']
    type_df_dic = {}
    type_75_dic = {}
    # 各分类project star以及分布数据
    for type in type_list:
        type_df = project_df[project_df['type'] == type].paper_star
        type_df_dic[type] = type_df

        # 计算超过75%star的项目数量，以及star占总star比例
        num_list = type_df.tolist()
        num_list = sorted(num_list)
        num_75 = num_list[int(len(num_list) * 0.95)]
        # num_75 = type_df.describe()['75%']
        type_75_dic[type] = num_75
        df_75 = type_df.loc[type_df > num_75]
        paper_num_75 = len(df_75)
        rate = sum(df_75) / sum(type_df)
        print(type, paper_num_75, rate, sep=',')

    # paper_df 增加主要模型标志列
    paper_df.loc[:, 'main_model'] = 'False'
    # 将各类型大于 75% star的project置为 TRUE
    for k, v in type_75_dic.items():
        paper_df.loc[(paper_df['paper_star'] > v) & (paper_df['type'] == k), 'main_model'] = 'True'

    paper_df.to_csv('./after_filter.csv', sep=',')

    get_to_collect_model(paper_df, type_list)

    # 画箱型图
    draw_box_pic(type_df_dic)


# 筛选出未收集的主流模型
def get_to_collect_model(df, type_list):
    for type in type_list:
        type_df = df.loc[(df['type'] == type) & (df['main_model'] == 'True'), :]
        print('--------------------------------')
        print(type, ' 主流数量: ', len(type_df), sep='')
        print(type_df.to_string())


# 获取github peoject 名称
def get_project_name(x):
    if ' official' in x:
        return x.split(' official')[0]
    else:
        return x.split('(https:')[0]


# 画箱型图，查看各分类star分布
def draw_box_pic(type_df_dic):
    cv_box = type_df_dic['CV']
    nlp_box = type_df_dic['NLP']
    generative_box = type_df_dic['Generative']
    rs_box = type_df_dic['Recommendation System']
    audio_box = type_df_dic['audio']
    cv_desc = cv_box.describe().to_string()
    nlp_desc = nlp_box.describe().to_string()
    generative_desc = generative_box.describe().to_string()
    rs_desc = rs_box.describe().to_string()
    audio_desc = audio_box.describe().to_string()
    plt.figure(figsize=(35, 20))
    plt.title('github project star boxplot')
    labels = 'cv\n' + cv_desc, 'nlp\n' + nlp_desc, 'generative\n' + generative_desc, 'rs\n' + rs_desc, 'audio\n' + audio_desc
    plt.boxplot([cv_box, nlp_box, generative_box, rs_box, audio_box], labels=labels, showmeans=False, showfliers=False)
    plt.savefig('./type_box.jpg')


if __name__ == '__main__':
    # compare_papers()
    # ana_papers()
    paper_list = ['Learning Transferable Architectures for Scalable Image Recognition',
                  'Neural Collaborative Filtering', 'Adversarial Autoencoders',
                  'Unified Generative Adversarial Networks for Multi-Domain Image-to-Image Translation',
                  'Unsupervised Image-to-Image Translation Networks', 'DARTS: Differentiable Architecture Search',
                  'Wide & deep learning for recommender systems',
                  'Learning to Discover Cross-Domain Relations with Generative Adversarial Networks',
                  'Deep Networks with Stochastic Depth', 'Coupled Generative Adversarial Networks',
                  'Multimodal Unsupervised Image-to-Image Translation',
                  'Smaller, faster, cheaper, lighter: Introducing DistilBERT, a distilled version of BERT',
                  'Unsupervised Pixel-Level Domain Adaptation with Generative Adversarial Networks',
                  'Factorizing Personalized Markov Chains for Next-Basket Recommendation',
                  'BEGAN: Boundary Equilibrium Generative Adversarial Networks',
                  'Energy-based Generative Adversarial Network', 'Searching for MobileNetV3',
                  'Dilated Residual Networks',
                  'Deepfm: a factorization-machine based neural network for ctr prediction',
                  'A Factorization-Machine based Neural Network for CTR Prediction',
                  'DeepFM: A Factorization-Machine based Neural Network for CTR Prediction',
                  'Toward Multimodal Image-to-Image Translation',
                  'One weird trick for parallelizing convolutional neural networks',
                  'Collaborative Knowledge Base Embedding for Recommender Systems',
                  'Neural factorization machines for sparse predictive analytics', 'Objects as Points',
                  'Collaborative denoising auto-encoders for top-n recommender systems',
                  'AN IMAGE IS WORTH 16X16 WORDS: TRANSFORMERS FOR IMAGE RECOGNITION AT SCALE (Vision Transformer)',
                  'ERFNet: Efficient Residual Factorized ConvNet for Real-time Semantic Segmentation',
                  'Deep interest network for click-through rate prediction', 'Deep Layer Aggregation',
                  'CondenseNet: An Efficient DenseNet using Learned Group Convolutions',
                  'Graph Convolutional Matrix Completion',
                  'SuperPoint: Self-Supervised Interest Point Detection and Description',
                  'FISM: factored item similarity models for top-N recommender systems',
                  'Semi-Supervised Learning with Generative Adversarial Networks',
                  'LinkNet: Exploiting Encoder Representations for Efficient Semantic Segmentation',
                  'Neural Attentive Session-based Recommendation',
                  'Personalized Top-N Sequential Recommendation via Convolutional Sequence Embedding',
                  'Attentional factorization machines: Learning the weight of feature interactions via attention networks',
                  'Reformer: The Efficient Transformer',
                  'Improved Recurrent Neural Networks for Session-based Recommendations',
                  'Deep Matrix Factorization Models for Recommender Systems',
                  'Deep & Cross Network for Ad Click Predictions', 'Deep & cross network for ad click predictions',
                  'Longformer: The Long-Document Transformer', 'Neural Graph Collaborative Filtering',
                  'Self-Attentive Sequential Recommendation',
                  'xDeepFM: Combining Explicit and Implicit Feature Interactions for Recommender Systems',
                  'CTRL: A Conditional Transformer Language Model for Controllable Generation',
                  'Joint 3D Face Reconstruction and Dense Alignment with Position Map Regression Network',
                  'Multi-Scale Dense Networks for Resource Efficient Image Classification',
                  'Shake-Shake regularization',
                  'Approximating CNNs with Bag-of-local-Features models works surprisingly well on ImageNet',
                  'Session-based Recommendation with Graph Neural Networks',
                  'Deep Learning over Multi-field Categorical Data - A Case Study on User Response Prediction',
                  'Knowledge Graph Attention Network for Recommendation',
                  'Parallel Recurrent Neural Network Architectures for Feature-rich Session-based Recommendations',
                  'PEGASUS: Pre-training with Extracted Gap-sentences for Abstractive Summarization',
                  'Product-based Neural Networks for User Response Prediction',
                  'Product-based neural networks for user response prediction',
                  'Short-Term Attention/Memory Priority Model for Session-based Recommendation',
                  'Dense Passage Retrieval for Open-Domain Question Answering',
                  'Deep Interest Evolution Network for Click-Through Rate Prediction',
                  'Multilingual Denoising Pre-training for Neural Machine Translation',
                  'Neural Attentive Item Similarity Model for Recommendation', 'i-RevNet: Deep Invertible Networks',
                  'Translation-based Recommendation', 'CamemBERT: a Tasty French Language Model',
                  'Sequential Recommendation with Bidirectional Encoder Representations from Transformer',
                  'Outer Product-based Neural Collaborative Filtering',
                  'Speeding up Semantic Segmentation for Autonomous Driving',
                  'Learning to Navigate for Fine-grained Classification',
                  'Residual Networks of Residual Networks: Multilevel Residual Networks',
                  'Big Bird: Transformers for Longer Sequences',
                  'ClusterGAN : Latent Space Clustering in Generative Adversarial Networks',
                  'AutoInt: Automatic Feature Interaction Learning via Self-Attentive Neural Networks',
                  'Automatic Feature Interaction Learning via Self-Attentive Neural Networks',
                  'Facebook FAIR\'s WMT19 News Translation Task Submission',
                  'Recipes for building an open-domain chatbot', 'Fast-SCNN: Fast Semantic Segmentation Network',
                  'Unifying Knowledge Graph Learning and Recommendation:Towards a Better Understanding of User Preferences',
                  'Boundary-Seeking Generative Adversarial Networks',
                  'Knowledge graph convolution networks for recommender systems',
                  'Towards Faster Training of Global Covariance Pooling Networks by Iterative Matrix',
                  'Multi-Task Feature Learning for Knowledge Graph Enhanced Recommendation',
                  'An End-to-End Convolutional Neural Acoustic Model',
                  'Semi-Supervised Learning with Context-Conditional Generative Adversarial Networks',
                  'Learning heterogeneous knowledge base embeddings for explainable recommendation',
                  'ContextNet: Exploring Context and Detail for Semantic Segmentation in Real-time',
                  'Knowledge-aware Graph Neural Networks with Label Smoothness Regularization for Recommender Systems',
                  'A convolutional click prediction model',
                  'FlauBERT: Unsupervised Language Model Pre-training for French',
                  'QuartzNet: Deep Automatic Speech Recognition with 1D Time-Channel Separable Convolutions',
                  'TAPAS: Weakly Supervised Table Parsing via Pre-training',
                  'DeBERTa: Decoding-enhanced BERT with Disentangled',
                  'Graph Contextualized Self-Attention Network for Session-based Recommendation',
                  'Production-Level Facial Performance Capture Using Deep Convolutional Neural Networks',
                  'CGNet: A Light-weight Context Guided Network for Semantic Segmentation',
                  'A Neural Collaborative Filtering Model with Interaction-based Neighborhood',
                  'Efficient Dense Modules of Asymmetric Convolution for Real-Time Semantic Segmentation',
                  'DABNet: Depth-wise Asymmetric Bottleneck for Real-time Semantic Segmentation',
                  'Learning Disentangled Representations for Recommendation',
                  'Learning Piece-wise Linear Models from Large Scale Data for Ad Click Prediction',
                  'XNect: Real-time Multi-person 3D Human Pose Estimation with a Single RGB Camera',
                  'Sparsely Aggregated Convolutional Networks',
                  'FiBiNET: Combining Feature Importance and Bilinear feature Interaction for Click-Through Rate Prediction',
                  'Real-time 2D Multi-Person Pose Estimation on CPU: Lightweight OpenPose',
                  'FD-MobileNet: Improved MobileNet with a Fast Downsampling Strategy',
                  'ChannelNets: Compact and Efficient Convolutional Neural Networks via Channel-Wise Convolutions',
                  'Learning Strict Identity Mappings in Deep Residual Networks',
                  'Feature-level Deeper Self-Attention Network for Sequential Recommendation',
                  'Improving Convolutional Networks with Self-Calibrated Convolutions',
                  'Beyond English-Centric Multilingual Machine Translation',
                  'Efficient Neural Matrix Factorization without Sampling for Recommendation',
                  'A new variational autoencoder for Top-N recommendations with implicit feedback',
                  'ShaResNet: reducing residual network parameter number by sharing weights',
                  'Auxiliary Classifier Generative Adversarial Network',
                  'Adaptive Factorization Network: Learning Adaptive-Order Feature Interactions',
                  'Self-Supervised Learning for Sequential Recommendation with Mutual Information Maximization',
                  'SqueezeBERT: What can computer vision teach NLP about efficient neural networks?',
                  'Feature Pyramid Encoding Network for Real-time Semantic Segmentation',
                  'LFFD: A Light and Fast Face Detector for Edge Devices',
                  'Deep Residual Network with Sparse Feedback for Image Restoration',
                  'Field-aware Neural Factorization Machine for Click-Through Rate Prediction',
                  'Attention Inspiring Receptive-Fields Network for Learning Invariant Representations',
                  'ReXNet: Diminishing Representational Bottleneck on Convolutional Neural Network',
                  'Operation-aware Neural Networks for User Response Prediction',
                  'An Input-aware Factorization Machine for Sparse Prediction',
                  'ESNet: An Efficient Symmetric Network for Real-time Semantic Segmentation',
                  'SINet: Extreme Lightweight Portrait Segmentation Networks with Spatial Squeeze Modules and Information Blocking Decoder',
                  'DIANet: Dense-and-Implicit Attention Network',
                  'A Dual Input-aware Factorization Machine for CTR Prediction', 'BAM: Bottleneck Attention Module']
    collect_paper_df = pd.read_csv('../data/extracted_feature_0610.csv')
    collect_paper_titles = collect_paper_df['model_paper']

    for paper in paper_list:
        type = collect_paper_df[collect_paper_df['model_paper'] == paper].model_type
        print(paper, type, sep=' ----- ')
