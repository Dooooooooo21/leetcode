def change_paper_name(paper):
    paper_dict = {
        'Semi-Supervised Generative Adversarial Network': 'Semi-Supervised Learning with Generative Adversarial Networks',
        'Facebook FAIR\’s WMT19 News Translation Task Submission': 'Facebook FAIR\'s WMT19 News Translation Task Submission',
        'Unpaired Image-to-Image Translation with Conditional Adversarial Networks': 'Image-to-Image Translation with Conditional Adversarial Networks',
        'Identity Mappings in Deep Residual Networks': 'Learning Strict Identity Mappings in Deep Residual Networks',
        'ClusterGAN: Latent Space Clustering in Generative Adversarial Networks': 'ClusterGAN : Latent Space Clustering in Generative Adversarial Networks',
        'Adversarial Autoencoder': 'Adversarial Autoencoders',
        'Generative Adversarial Network': 'Generative Adversarial Networks',
        'Reformer: The Efficient Transformer ': 'Reformer: The Efficient Transformer',
        'Squeezenet: Alexnet-level accuracy with 50x fewer parameters and< 0.5 mb model size': 'SqueezeNet: AlexNet-level accuracy with 50x fewer parameters and <0.5MB model size',
        'FD-MobileNet: Improved MobileNet with A Fast Downsampling Strategy': 'FD-MobileNet: Improved MobileNet with a Fast Downsampling Strategy',
        'Mask R - CNN': 'Mask R-CNN'

    }
